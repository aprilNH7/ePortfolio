/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Date;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class AppointmentServiceTest {

    public AppointmentServiceTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of addAppointment method, of class AppointmentService.
     */
    @Test
    public void testAddAppointment() {
        System.out.println("addAppointment");
        Appointment app = new Appointment("IDI");
        app.setAppointment_date(new Date());
        app.setDescription("dESCRIPTION");
        AppointmentService instance = new AppointmentService();

        boolean result = instance.addAppointment(app);
        assertEquals(instance.getAppointments().size(), 1);

    }

    /**
     * Test of deleteAppointment method, of class AppointmentService.
     */
    @Test
    public void testDeleteAppointment() {
        System.out.println("addAppointment");
        Appointment app = new Appointment("IDI");
        app.setAppointment_date(new Date());
        app.setDescription("dESCRIPTION");
        AppointmentService instance = new AppointmentService();

        boolean result = instance.addAppointment(app);
        instance.deleteAppointment("IDI");

        assertEquals(instance.getAppointments().size(), 0);
    }

}
