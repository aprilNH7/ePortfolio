/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Date;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author: April Nixon
 */
public class AppointmentTest {

    public AppointmentTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getAppointment_id method, of class Appointment.
     */
    @Test
    public void testGetAppointment_id() {
        System.out.println("getAppointment_id");
        Appointment instance = new Appointment("IDI");
        String expResult = "IDI";
        String result = instance.getAppointment_id();
        assertEquals(expResult, result);

    }

    /**
     * Test of getDescription method, of class Appointment.
     */
    @Test
    public void testGetDescription() {
        System.out.println("getDescription");
        Appointment instance = new Appointment("IDI");
        instance.setDescription("HERE WE GO");
        String expResult = "";
        String result = instance.getDescription();
        assertEquals("HERE WE GO", result);

    }

    /**
     * Test of setDescription method, of class Appointment.
     */
    @Test
    public void testSetDescription() {
        System.out.println("setDescription");
        String description = "";
        Appointment instance = null;

        try {
            instance.setDescription(description);

        } catch (Exception exc) {

            assertTrue(true);
        }

    }



     /**
     * Test of setDescription method, of class Appointment.
     */
    @Test
    public void testSetDate() {
        System.out.println("setDate");
        String description = "";
        Appointment instance = null;

        try {
            instance.setAppointment_date(new Date());

        } catch (Exception exc) {

            assertTrue(true);
        }

    }

}
