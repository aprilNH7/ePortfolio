
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author: April Nixon
 */
public class AppointmentService {

    protected ArrayList<Appointment> appointments;
    



    public AppointmentService() {

        appointments = new ArrayList<>();
    }

    public boolean addAppointment(Appointment app) {

        for (int x = 0; x < appointments.size(); x++) {

            if (app.getAppointment_id().equals(appointments.get(x).getAppointment_id())) {

                return false;
            }

        }

        appointments.add(app);
        return true;

    }

    public boolean deleteAppointment(String id) {

        for (int x = 0; x < appointments.size(); x++) {

            if (id.equals(appointments.get(x).getAppointment_id())) {

                appointments.remove(x);
                return true;
            }

        }

        return false;

    }

    public ArrayList<Appointment> getAppointments() {
        return appointments;
    }




}
