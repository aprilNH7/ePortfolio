
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author: April Nixon
 */
public class Appointment {

    private final String appointment_id;
    private Date appointment_date;
    private String description;

    public Appointment(String appointment_id) {
        this.appointment_id = appointment_id;
    }

    public Appointment(String appointment_id, Date appointment_date, String description) {

        if (appointment_id != null && appointment_date.before(new Date()) == true && description != null) {

            throw new customException("Values cant be null");

        }

        if(appointment_id.length() > 10){

            throw new customException("Appointmnt id should be <= 10");

        }



         if(description.length() > 50){

            throw new customException("Appointmnt description should be <= 50");

        }

        this.appointment_id = appointment_id;
        this.appointment_date = appointment_date;
        this.description = description;

    }

    public String getAppointment_id() {
        return appointment_id;
    }

    public Date getAppointment_date() {
        return appointment_date;
    }

    public void setAppointment_date(Date appointment_date) {


        this.appointment_date = appointment_date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {

        if(description.length() > 50){

            throw new customException("Appointmnt description should be <= 50");

        }


        this.description = description;
    }



}

class customException extends NullPointerException{

    public customException(String message) {
        super(message);
    }



}
