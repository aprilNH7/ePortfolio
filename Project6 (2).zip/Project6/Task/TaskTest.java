// Needed to Run Junit tests
import org.junit.After;
import org.junit.AfterClass;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
// Needed to make junit tests
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.BeforeClass;
// Needed to handle expected Assertion Exceptions
import org.junit.Rule;
import org.junit.rules.ExpectedException;

public class TaskTest {
    
    
    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }
    
    @Test
    // Simple main function to run all Junit tests
    public void mainTest() {
        Result result = JUnitCore.runClasses(TaskTest.class);

        // Print all failed test cases (none happen fortunately as of right now)
        for(Failure fail: result.getFailures()) {
            System.out.println(fail);
        }

        if(result.wasSuccessful()) {
            System.out.println("TaskTest - all tests passed");
        } else {
            System.out.println("TaskTest - some tests failed");
        }
    }

    // Valid set of inputs
    private final String ID = "024681359";
    private final String Name = "John Johnson";
    private final String Description = "Testing Task Object 1";

    // Invalid inputs
    private final String badID = "12345678901";
    private final String badName = "Way too long of a name here";
    private final String badDescription = "I was born in the year 3050. My parents were pretty old and were in their 50s when they had me. Anyways this description is way too long and should error out.";

    // Setter inputs
    private final String ID2 = "159";
    private final String Name2 = "Jilly Bean";
    private final String Description2 = "Second Task object description";

    // Object to be tested in construction
    private final Task testTask = new Task(ID, Name, Description);

    // Exception catching rule
    @Rule
    public ExpectedException rule = ExpectedException.none();

    @Test
    public void testTask() {
        System.out.println("Task constructor tests");

        System.out.printf("\tID should be %s\n", ID);
        assertEquals(ID, testTask.getId());

        System.out.printf("\tName should be %s\n", Name);
        assertEquals(Name, testTask.getName());

        System.out.printf("\tDescription should be %s\n", Description);
        assertEquals(Description, testTask.getDescription());

        System.out.println("\tTesting that providing a null input causes assertion error");
        rule.expect(AssertionError.class);
        new Task(null, null, null);
    }

    @Test
    public void testID() {
        System.out.println("ID setting test");

        System.out.printf("\tFollowing ID should give error: %s\n", badID);
        rule.expect(AssertionError.class);
        new Task(badID, Name, Description);
    }

    @Test
    public void testName() {
        System.out.println("Name getting and setting test");
        Task secondTask = new Task(ID2, Name, Description);

        System.out.printf("\tChange name to %s\n", Name2);
        secondTask.setName(Name2);
        assertEquals(Name2, secondTask.getName());

        System.out.printf("\tMaking name the following should give error: %s\n", badName);
        rule.expect(AssertionError.class);
        secondTask.setName(badName);
    }

    @Test
    public void testDescription() {
        System.out.println("Description getting/setting test");
        Task secondTask = new Task(ID2, Name, Description);

        System.out.printf("\tChange description to %s\n", Description2);
        secondTask.setDescription(Description2);
        assertEquals(Description2, secondTask.getDescription());

        System.out.printf("\tThe following description should give error: %s\n", badDescription);
        rule.expect(AssertionError.class);
        secondTask.setDescription(badDescription);
    }
}
