// Use a HashMap to make service/task mapping efficient
import java.util.HashMap;

// TaskService object source code
public class TaskService {
    HashMap<String, Task> services;

    // Constructor for Task Service object
    public TaskService() { services = new HashMap<String, Task>(); }

    // Constructor where task is given
    public TaskService(Task task) {
        services = new HashMap<String, Task>();
        services.put(task.getId(), task);
    }


    // Insert a task into the services if key doesn't exist
    public boolean addTask(Task task) {
        if(task != null && services.containsKey(task.getId()) == false) { // Can insert task
            services.put(task.getId(), task);
            return true;
        }

        return false;
    }

    // Update a task such that the task's id should exist, but we'll overwrite the underlying task object
    public boolean updateTask(Task task) {
        if(task != null && services.containsKey(task.getId()) == true) {
            // safe to update - notice that we need to get the actual Task
            // and change its fields as specified by instructions
            Task toChange = services.get(task.getId());
            toChange.setName(task.getName());
            toChange.setDescription(task.getDescription());
            return true;
        }

        return false;
    }

    // Remove task by ID
    public boolean removeTask(Task task) {
        if(task != null && services.containsKey(task.getId())) {
            services.remove(task.getId());
            return true;
        }

        return false;
    }

    // Helper to retrieve tasks from the hashmap for testing purposes (null if id doesn't exist)
    public Task getTask(Task task) {
        if(task == null) {
            return null;
        }

        // hashmap built-in lets us perform functionality in a nice way if key not found
        return services.getOrDefault(task.getId(), null);
    }

    // Return number of keys in hashmap
    public int getSize() {
        return services.size();
    }
}
