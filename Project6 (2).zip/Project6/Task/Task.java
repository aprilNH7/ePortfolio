// Task Object source code
public class Task {
    private final String ID;
    private String Name;
    private String Description;

    // Constructor for Task object
    public Task(String ID_, String Name_, String Description_) {
        // Make sure all inputs are correct - only ID setting needs to be checked here since
        // that cannot be set later
        assert ID_ != null && ID_.length() <= 10 : "Constructor - ID field is incorrect";

        // Set everything
        ID = ID_;
        setName(Name_);
        setDescription(Description_);
    }

    // Return ID object
    public String getId() { return ID; }

    // Return Name object
    public String getName() { return Name; }

    // Set Name object
    public void setName(String Name_) {
        assert Name_ != null && Name_.length() <= 20 : "setName - Name field is incorrect";
        Name = Name_;
    }

    // Return Description object
    public String getDescription() { return Description; }

    // Set Description object
    public void setDescription(String Description_) {
        assert Description_ != null && Description_.length() <= 50 : "setDescription - Description field is incorrect";
        Description = Description_;
    }

    // Method for printing/treating the Task object as a String
    public String toString() {
        return "(" + ID + ", " + Name + ", " + Description + ")";
    }


    // Method used to compare Task objects
    @Override
    public boolean equals(Object obj) {
        if(obj == null || obj.getClass() != Task.class) {
            return false;
        }

        // Convert obj to Task and grab fields
        Task task = (Task) obj;
        return ID.equals(task.getId()) && Name.equals(task.getName()) && Description.equals(task.getDescription());
    }
}
