#include <GLFW/glfw3.h>
#include <iostream>
#include <vector>
#include <time.h>
#include <GL/gl.h>
#include <cmath>

using namespace std;

const float DEG2RAD = 3.14159 / 180;

enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE };
enum ONOFF { ON, OFF };

class Brick
{
public:
    float red, green, blue,opacity;
    float x, y, width;
    
    BRICKTYPE brick_type;
    ONOFF onoff;

    Brick(BRICKTYPE bt, float xx, float yy, float ww, float rr, float gg, float bb)
    {
        brick_type = bt; x = xx; y = yy, width = ww; red = rr, green = gg, blue = bb;
        onoff = ON;
        opacity = 1.0;
    };

    void drawBrick() const
    {
        if (onoff == ON)
        {
            double halfside = width / 2;

            glColor4d(red, green, blue, opacity);
            glBegin(GL_POLYGON);

            glVertex2d(x + halfside, y + halfside);
            glVertex2d(x + halfside, y - halfside);
            glVertex2d(x - halfside, y - halfside);
            glVertex2d(x - halfside, y + halfside);

            glEnd();
        }
    }

    void diming() {

        opacity *= 0.99;

    }

    bool disapeared() {
        if (red < 0.01 && green < 0.001 && blue < 0.001) {
            return true; 
        }
        else {
            return false; 
        }
    }
};



class Circle
{
public:
    float red, green, blue;
    float radius;
    float x;
    float y;
    float speed = 0.001;
    int direction; // 1=up 2=right 3=down 4=left 5 = up right   6 = up left  7 = down right  8= down left

    Circle(double xx, double yy, double rr, int dir, float rad, float r, float g, float b)
    {
        x = xx;
        y = yy;
        radius = rr;
        red = r;
        green = g;
        blue = b;
        radius = rad;
        direction = dir;
    }

    void drawCircle() {
        const int num_segments = 100;
        glColor3f(red, green, blue);
        glBegin(GL_TRIANGLE_FAN);
        for (int i = 0; i < num_segments; i++) {
            float theta = 2.0f * 3.1415926f * float(i) / float(num_segments); // The current angle
            float dx = radius * cosf(theta); // The x component
            float dy = radius * sinf(theta); // The y component
            glVertex2f(x + dx, y + dy); // Output vertex
        }
        glEnd();
    }

    void CheckCollision( Brick* brk)
    {
        if (brk->brick_type == REFLECTIVE)
        {
            if ((x > brk->x - brk->width && x <= brk->x + brk->width) && (y > brk->y - brk->width && y <= brk->y + brk->width))
            {
                direction = GetRandomDirection();
                x = x + 0.03;
                y = y + 0.04;
            }
        }
        else if (brk->brick_type == DESTRUCTABLE)
        {
            if ((x > brk->x - brk->width && x <= brk->x + brk->width) && (y > brk->y - brk->width && y <= brk->y + brk->width))
            {
                //Dim the brick
                brk->diming();

                
                          

            }
           
        }
    }

    int GetRandomDirection()
    {
        return (rand() % 8) + 1;
    }

    void MoveOneStep()
    {
        if (direction == 1 || direction == 5 || direction == 6)  // up
        {
            if (y > -1 + radius)
            {
                y -= speed;
            }
            else
            {
                direction = GetRandomDirection();
            }
        }

        if (direction == 2 || direction == 5 || direction == 7)  // right
        {
            if (x < 1 - radius)
            {
                x += speed;
            }
            else
            {
                direction = GetRandomDirection();
            }
        }

        if (direction == 3 || direction == 7 || direction == 8)  // down
        {
            if (y < 1 - radius) {
                y += speed;
            }
            else
            {
                direction = GetRandomDirection();
            }
        }

        if (direction == 4 || direction == 6 || direction == 8)  // left
        {
            if (x > -1 + radius)
            {
                x -= speed;
            }
            else
            {
                direction = GetRandomDirection();
            }
        }
    }
};

int main() {
    // Initialize GLFW
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return -1;
    }

    // Create a windowed 
    GLFWwindow* window = glfwCreateWindow(800, 600, "2D Collision-based Animation", NULL, NULL);
    if (!window) {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }

    // Make the window's context current
    glfwMakeContextCurrent(window);

    // Enable blending for transparency
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // Seed random number generator
    srand(time(NULL));

    // Create bricks
    vector<Brick> bricks;
    float brickWidth = 0.1f;
    float brickGap = 0.01f;
    float startX = -0.8f + brickWidth / 2.0f;
    float startY = -0.8f;

    // Initialize the random number generator with the current time
    srand(time(NULL));

    for (int i = 0; i < 14; ++i) {
        for (int j = 0; j < 14; ++j) {
            // Generate a random float between 0 and 1
            float randomNum1 = static_cast<float>(rand()) / static_cast<float>(RAND_MAX);
            float randomNum2 = static_cast<float>(rand()) / static_cast<float>(RAND_MAX);
            float randomNum3 = static_cast<float>(rand()) / static_cast<float>(RAND_MAX);

            float x = startX + j * (brickWidth + brickGap);
            float y = startY + i * (brickWidth + brickGap);

            // Use the random numbers for the color
            Brick brick(DESTRUCTABLE, x, y, brickWidth, randomNum1, randomNum2, randomNum3);
            bricks.push_back(brick);
        }
    }




    // Initialize circle
    //Circle(double xx, double yy, double rr, int dir, float rad, float r, float g, float b)
    Circle circle(0.0f, 0.0f, 0.1f, 1, 0.05f, 1.0f, 0.0f, 0.0f);

    while (!glfwWindowShouldClose(window)) {

        // Clear the color buffer
        glClear(GL_COLOR_BUFFER_BIT);

        // Render here
        circle.drawCircle();

        circle.MoveOneStep();

        // Render bricks
        for (Brick& brick : bricks) {

            circle.CheckCollision(&brick);
            
            brick.drawBrick();
           
        }
        
        // Swap front and back buffers
        glfwSwapBuffers(window);

        // Poll for and process events
        glfwPollEvents();
    }

    // Clean up GLFW before exiting
    glfwTerminate();

    return 0;
}
